import os

command = "pyuic4 -o ui_multiqml.py multiqml.ui"
print command
os.system( command )
