#include <QCloseEvent>
#include <QSettings>

#include "qgsgeorefconfigdialog.h"

QgsGeorefConfigDialog::QgsGeorefConfigDialog(QWidget *parent) :
    QDialog(parent){
  setupUi(this);

  readSettings();
}

void QgsGeorefConfigDialog::changeEvent(QEvent *e)
{
  QDialog::changeEvent(e);
  switch (e->type()) {
  case QEvent::LanguageChange:
    retranslateUi(this);
    break;
  default:
    break;
  }
}

void QgsGeorefConfigDialog::on_buttonBox_accepted()
{
  writeSettings();
  accept();
}

void QgsGeorefConfigDialog::on_buttonBox_rejected()
{
  reject();
}

void QgsGeorefConfigDialog::readSettings()
{
  QSettings s;
  if (s.value("/Plugin-GeoReferencer/Config/ShowId").toBool())
    mShowIDsRadioButton->setChecked(true);
  else
    mShowCoordsRadioButton->setChecked(true);
}

void QgsGeorefConfigDialog::writeSettings()
{
  QSettings s;
  s.setValue("/Plugin-GeoReferencer/Config/ShowId", mShowIDsRadioButton->isChecked());
}
