#ifndef QGSGEOREFDELETEPOINT_H
#define QGSGEOREFDELETEPOINT_H

class QgsGeorefDeletePoint
{
public:
    QgsGeorefDeletePoint();
};

#endif // QGSGEOREFDELETEPOINT_H
