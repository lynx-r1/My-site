#include "qgsgeorefdeletepoint.h"

QgsGeorefDeletePoint::QgsGeorefDeletePoint()
{
}
