#ifndef QGSGEOREFTOOLREMOVEPOINT_H
#define QGSGEOREFTOOLREMOVEPOINT_H

class QgsGeorefToolRemovePoint
{
public:
    QgsGeorefToolRemovePoint();
};

#endif // QGSGEOREFTOOLREMOVEPOINT_H
