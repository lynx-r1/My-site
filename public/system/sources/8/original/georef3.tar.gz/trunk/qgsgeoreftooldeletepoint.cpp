#include "qgsmapcanvas.h"

#include "qgsgeoreftooldeletepoint.h"

QgsGeorefToolDeletePoint::QgsGeorefToolDeletePoint( QgsMapCanvas* canvas )
  : QgsMapToolEmitPoint( canvas )
{
}

// Mouse press event for overriding
void QgsGeorefToolDeletePoint::canvasPressEvent( QMouseEvent * e )
{
  // Only add point on Qt:LeftButton
  if ( Qt::LeftButton == e->button() )
  {
    emit deleteDataPoint(e->pos());
  }
}
