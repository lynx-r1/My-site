#ifndef QGSOPENRASTERDIALOG_H
#define QGSOPENRASTERDIALOG_H

#include "ui_qgsopenrasterdialogbase.h"

class QgsOpenRasterDialog : public QDialog, private Ui::QgsOpenRasterDialog {
  Q_OBJECT
public:
  QgsOpenRasterDialog(QWidget *parent = 0);
  void getRasterOptions(QString &rasterFileName, QString &modifiedFileName, QString &worldFileName);

protected:
  void changeEvent(QEvent *e);

private slots:
  void on_tbnSelectRaster_clicked();
  void on_tbnSelectModifiedRaster_clicked();

  void on_leModifiedRasterFileName_textChanged(const QString name);

private:
  QString generateModifiedRasterFileName();
  QString guessWorldFileName( const QString rasterFileName );

  QString mWorldFileName;
};

#endif // QGSOPENRASTERDIALOG_H
