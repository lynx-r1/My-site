#ifndef QGSGEOREFVALIDATORS_H
#define QGSGEOREFVALIDATORS_H

#include <QValidator>

class QgsDMSAndDDValidator : public QValidator
{
public:
  QgsDMSAndDDValidator(QObject *parent);
  State validate(QString &input, int &pos) const;
};

#endif // QGSGEOREFVALIDATORS_H
