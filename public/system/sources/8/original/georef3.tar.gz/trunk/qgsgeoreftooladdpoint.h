#ifndef QGSGEOREFTOOLADDPOINT_H
#define QGSGEOREFTOOLADDPOINT_H

#include <QMouseEvent>

#include "qgsmaptoolemitpoint.h"

class QgsPoint;
class QgsMapCanvas;

class QgsGeorefToolAddPoint : public QgsMapToolEmitPoint
{
  Q_OBJECT

public:
  QgsGeorefToolAddPoint( QgsMapCanvas* canvas );

  // Mouse events for overriding
  void canvasPressEvent( QMouseEvent * e );

signals:
  void showCoordDailog( const QgsPoint & );
};

#endif // QGSGEOREFTOOLADDPOINT_H
