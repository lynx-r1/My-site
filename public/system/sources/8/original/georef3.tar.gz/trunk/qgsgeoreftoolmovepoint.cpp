#include "qgsmapcanvas.h"

#include "qgsgeoreftoolmovepoint.h"

QgsGeorefToolMovePoint::QgsGeorefToolMovePoint(QgsMapCanvas *canvas)
  : QgsMapTool(canvas)
  , mRubberBand(0)
{
}

void QgsGeorefToolMovePoint::canvasPressEvent(QMouseEvent *e)
{
  if (e->button() & Qt::LeftButton)
  {
    mStartPointMapCoords = e->pos();
    emit pointPressed(e->pos());
  }
}

void QgsGeorefToolMovePoint::canvasMoveEvent(QMouseEvent *e)
{
  emit pointMoved(e->pos());
}

void QgsGeorefToolMovePoint::canvasReleaseEvent(QMouseEvent *e)
{
  emit pointReleased(e->pos());
}
