#include "qgsgeoreftoolremovepoint.h"

QgsGeorefToolRemovePoint::QgsGeorefToolRemovePoint()
{
}
