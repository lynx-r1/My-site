#ifndef QGSGEOREFTOOLDELETEPOINT_H
#define QGSGEOREFTOOLDELETEPOINT_H

#include <QMouseEvent>

#include "qgsmaptoolemitpoint.h"

class QgsPoint;
class QgsMapCanvas;

class QgsGeorefToolDeletePoint : public QgsMapToolEmitPoint
{
  Q_OBJECT

public:
  QgsGeorefToolDeletePoint(QgsMapCanvas* canvas);

  // Mouse events for overriding
  void canvasPressEvent( QMouseEvent * e );

signals:
  void deleteDataPoint( const QPoint & );
};

#endif // QGSGEOREFTOOLDELETEPOINT_H
