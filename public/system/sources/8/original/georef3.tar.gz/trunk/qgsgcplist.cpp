#include "qgspoint.h"
#include "qgsgeorefdatapoint.h"

#include "qgsgcplist.h"

QgsGCPList::QgsGCPList()
  : QList<QgsGeorefDataPoint *>()
{
}

QgsGCPList::QgsGCPList(const QgsGCPList &list)
{
  clear();
  QgsGCPList::const_iterator it = list.constBegin();
  for (; it != list.constEnd(); ++it)
  {
    QgsGeorefDataPoint *pt = new QgsGeorefDataPoint(**it);
    append(pt);
  }
}

void QgsGCPList::createGCPVectors(std::vector<QgsPoint> &mapCoords,
                                  std::vector<QgsPoint> &pixelCoords)
{
  mapCoords   = std::vector<QgsPoint>(size());
  pixelCoords = std::vector<QgsPoint>(size());
  for (int i = 0, j = 0; i < sizeAll(); i++)
  {
    QgsGeorefDataPoint *pt = at(i);
    if (pt->isEnabled())
    {
      mapCoords[j] = pt->mapCoords();
      pixelCoords[j] = pt->pixelCoords();
      j++;
    }
  }
}

int QgsGCPList::size() const
{
  if (QList<QgsGeorefDataPoint *>::isEmpty())
    return 0;

  int s = 0;
  const_iterator it = begin();
  while (it != end())
  {
    if ((*it)->isEnabled()) s++;
    it++;
  }
  return s;
}

int QgsGCPList::sizeAll() const
{
  return QList<QgsGeorefDataPoint *>::size();
}

QgsGCPList &QgsGCPList::operator =(const QgsGCPList &list)
{
  clear();
  QgsGCPList::const_iterator it = list.constBegin();
  for (; it != list.constEnd(); ++it)
  {
    QgsGeorefDataPoint *pt = new QgsGeorefDataPoint(**it);
    append(pt);
  }
  return *this;
}
