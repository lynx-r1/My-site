#ifndef QGSGCPCANVASITEM_H
#define QGSGCPCANVASITEM_H

#include "qgsmapcanvas.h"
#include "qgsmapcanvasitem.h"

class QgsGCPCanvasItem : public QgsMapCanvasItem {
public:
  QgsGCPCanvasItem( QgsMapCanvas* mapCanvas, const QgsPoint& rasterCoords,
                    const QgsPoint& worldCoords, bool isGCPSource/* = true*/ );

  //! draws point information
  void paint( QPainter* p );

  //! handler for manual updating of position and size
  QRectF boundingRect() const;

  QPainterPath shape() const;

  void setEnabled(bool enabled);

  void setRasterCoords(QgsPoint p);
  void setWorldCoords(QgsPoint p);

  int id() { return mId; }
  void setId(int id);

  void updatePosition();

private:
  QSizeF mTextBounds;
  QBrush mPointBrush;
  QBrush mLabelBrush;
  QgsPoint mRasterCoords;
  QgsPoint mWorldCoords;

  int mId;
  bool mIsGCPSource;
  bool mEnabled;
};

#endif // QGSGCPCANVASITEM_H
