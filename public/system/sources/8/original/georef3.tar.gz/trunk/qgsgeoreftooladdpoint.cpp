#include "qgsmapcanvas.h"

#include "qgsgeoreftooladdpoint.h"

QgsGeorefToolAddPoint::QgsGeorefToolAddPoint( QgsMapCanvas* canvas )
  : QgsMapToolEmitPoint( canvas )
{
}

// Mouse press event for overriding
void QgsGeorefToolAddPoint::canvasPressEvent( QMouseEvent * e )
{
  // Only add point on Qt:LeftButton
  if ( Qt::LeftButton == e->button() )
  {
    emit showCoordDailog( toMapCoordinates( e->pos() ) );
  }
}
